const customerSchema = require("../model/customer");
const bcrypt = require("bcryptjs");

exports.customerRegister = async (req, res) => {
    try {
        const encryptedPassword = await bcrypt.hash(req.body.password, 10);
        req.body.password = encryptedPassword;
        const data = await customerSchema.create(req.body);
    } catch (err) {
        console.log(err)
    }
    res.status(200).json({ msg: "verify" });
}
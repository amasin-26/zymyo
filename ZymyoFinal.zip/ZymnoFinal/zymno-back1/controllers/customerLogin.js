const customerSchema = require("../model/customer");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs")

exports.customerLogin = async (req, res) => {
    const data = await customerSchema.findOne({ email: req.body.email });
    console.log(data);
    let msg = "not-verify",
        token;
    try {
        if (await bcrypt.compare(req.body.password, data.password)) {
            msg = "verify";
            token = await jwt.sign({ email: req.body.email }, "12345", {
                expiresIn: "2h",
            });
        }
    } catch (err) {
        console.log(err);
    }
    res.status(200).json({ msg, token });
}
const chefSchema = require("../model/chef");
const customerSchema = require("../model/customer");
const jwt = require("jsonwebtoken");

exports.verifyToken = async(req, res) => {
    const { token, profiles } = req.body;
    const decode = jwt.verify(token, "12345");
    console.log(decode, token, profiles, "))))")
    let dataUser;
    if (profiles == "chef") {
        dataUser = await chefSchema.findOne({ email: decode.email });
        console.log(dataUser);
    } else if (profiles == "customer") {
        dataUser = await customerSchema.findOne({ email: decode.email });
        console.log(dataUser);
    }
    res.status(200).json({ data: { verified: true, authenticate: true, profile: profiles } });

}
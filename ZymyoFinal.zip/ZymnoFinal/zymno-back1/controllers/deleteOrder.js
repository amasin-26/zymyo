const MenuSchema = require("../model/menu");

exports.deleteReciepe = async(req, res) => {
    const reciepe = await MenuSchema.findByIdAndDelete(req.body._id);
    res.status(200).json({ reciepe });
}
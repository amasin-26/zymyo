const chefSchema = require("../model/chef");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

exports.chefRegister = async (req, res) => {
    let ChefData = req.body;
    try {
        const encryptedPassword = await bcrypt.hash(ChefData.password, 10);
        ChefData.password = encryptedPassword;
        const data = await chefSchema.create(ChefData);
    } catch (err) {
        cosnole.log(err);
    }
    res.status(200).json({ msg: "verify" });
}
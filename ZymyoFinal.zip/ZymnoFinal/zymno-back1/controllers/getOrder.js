const orderSchema = require("../model/order");

exports.getOrder = async(req, res) => {
    let { name, order } = req.body;
    // order = []
    console.log(name, order);
    for (let data of order) {
        const MenuData = await orderSchema.find({ name, data: data });
        console.log(MenuData);
        console.log(data, "@@@")
        if (MenuData.length == 0) {
            await orderSchema.create({ name, data });
        }
    }
    res.status(200).json({ msg: "Successfully", order });
}

exports.cancleOrder = async(req, res) => {
    let { name, order } = req.body;
    console.log(name, order, "#############################^^^^^^^^^^^^^^^^^^^^^^^^^");
    const MenuData = await orderSchema.deleteOne({ name, data: order });
    console.log("deleted", MenuData);
    res.status(200).json({ msg: "Successfully", order });
}
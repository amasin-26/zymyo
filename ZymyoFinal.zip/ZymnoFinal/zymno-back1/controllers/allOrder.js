const MenuSchema = require("../model/order");

exports.getOrder = async(req, res) => {
    let { name } = req.body;
    console.log(name, "##############################################");
    const orderData = await MenuSchema.find({ name });
    console.log(orderData);
    // console.log(MenuData);
    let orders = orderData.map((doc) => doc.data);
    console.log(orders, "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    res.status(200).json({ msg: "Successfully", order: orders });
}
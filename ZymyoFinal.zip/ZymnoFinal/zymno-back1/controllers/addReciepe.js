const MenuSchema = require("../model/menu");

exports.addReciepe = async(req, res) => {
    console.log("===-~~~~~~~~~~~~~~~~~~~~~~~~~", req.body)
    const { image, name, description, cookName, time } = req.body.dish;
    const reciepe = await MenuSchema.create({ image, name, description, cookName, time });
    res.status(200).json({ reciepe });
}
const MenuSchema = require("../model/menu");

exports.getMenu = async (req, res) => {
    const MenuData = await MenuSchema.find();
    // console.log(MenuData);
    res.status(200).json({ msg: "Successfully", data: MenuData });
}
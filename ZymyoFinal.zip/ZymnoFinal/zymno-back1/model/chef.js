const mongoose = require("mongoose");

const chefSchema = new mongoose.Schema({
    name: { type: String },
    experience: { type: Number },
    email: { type: String },
    phone: { type: String },
    address: { type: String },
    password: { type: String },
    reciepe: { type: String }
});

module.exports = mongoose.model("chef", chefSchema);
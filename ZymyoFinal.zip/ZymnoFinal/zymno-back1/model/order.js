const mongoose = require("mongoose");

const OrderSchema = new mongoose.Schema({
    // image: { type: String },
    name: { type: String },
    // description: { type: String },
    // cookName: { type: String },
    // time: { type: String },
    orderTime: { type: Date, default: new Date() },
    data: { type: mongoose.Schema.Types.Mixed },
    status: { type: String }
});

module.exports = mongoose.model("order", OrderSchema);
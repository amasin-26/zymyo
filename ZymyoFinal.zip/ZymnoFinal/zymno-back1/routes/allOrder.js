const express = require("express");
const { getOrder } = require("../controllers/allOrder");
const Router = express.Router();

Router.post("/", getOrder);

module.exports = Router;
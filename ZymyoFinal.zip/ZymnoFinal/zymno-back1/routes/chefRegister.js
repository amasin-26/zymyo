const express = require("express");
const { chefRegister } = require("../controllers/chefRegister");
const Router = express.Router();

Router.post("/", chefRegister);

module.exports = Router;
const express = require("express");
const { customerRegister } = require("../controllers/customerRegister");
const Router = express.Router();

Router.post("/", customerRegister);

module.exports = Router;
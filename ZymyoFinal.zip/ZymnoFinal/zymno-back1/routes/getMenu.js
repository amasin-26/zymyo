const express = require("express");
const { getMenu } = require("../controllers/getMenu");
const Router = express.Router();

Router.post("/", getMenu);

module.exports = Router;
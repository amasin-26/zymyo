const express = require("express");
const { chefLogin } = require("../controllers/chefLogin");
const Router = express.Router();

Router.post("/", chefLogin);

module.exports = Router;
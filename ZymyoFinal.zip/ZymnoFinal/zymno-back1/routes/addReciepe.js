const express = require("express");
const { addReciepe } = require("../controllers/addReciepe");
const Router = express.Router();

Router.post("/", addReciepe);

module.exports = Router;
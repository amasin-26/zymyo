const express = require("express");
const { customerLogin } = require("../controllers/customerLogin");
const Router = express.Router();

Router.post("/", customerLogin);

module.exports = Router;
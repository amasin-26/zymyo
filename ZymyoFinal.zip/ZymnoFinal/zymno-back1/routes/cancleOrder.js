const express = require("express");
const { cancleOrder } = require("../controllers/getOrder.js");
const Router = express.Router();

Router.post("/", cancleOrder);

module.exports = Router;
const express = require("express");
const { deleteReciepe } = require("../controllers/deleteOrder")
const Router = express.Router();

Router.post("/", deleteReciepe);

module.exports = Router;
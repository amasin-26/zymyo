const express = require("express");
const { verifyToken } = require("../controllers/verifyToken.js")
const Router = express.Router();

Router.post("/", verifyToken);

module.exports = Router;
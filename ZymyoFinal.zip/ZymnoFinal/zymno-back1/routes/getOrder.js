const express = require("express");
const { getOrder } = require("../controllers/getOrder.js");
const Router = express.Router();

Router.post("/", getOrder);

module.exports = Router;
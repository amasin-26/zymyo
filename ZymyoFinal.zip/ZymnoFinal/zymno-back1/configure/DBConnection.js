const mongoose = require("mongoose");

const URL = "mongodb://127.0.0.1:27017/Zymno";

exports.connect = async () => {
    mongoose.connect(URL, {
        useNewUrlParser: true
    }).then(() => {
        console.log("Connected To DB!")
    }).catch((err) => {
        console.log("Error in Connection!", err)
    });


}
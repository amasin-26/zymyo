import React,{useState, useEffect} from "react";
import "./FoodCardGrid.css"; // Import the CSS for the grid layout
import { Button } from "@mui/material";
import axios from 'axios';

const FoodCardGrid = ({ foodData }) => {


    const [addOrder,setAddOrder] = useState([]);
    const name= localStorage.getItem("name");


    useEffect(()=>{
        axios.post("http://localhost:8000/getOrder",{name,order:addOrder}).then((data)=>{
            console.log(data.data);
        }).catch((err)=>{
            console.log(err);
        });
    },[JSON.stringify(addOrder)]);

    useEffect(()=>{
        axios.post("http://localhost:8000/allOrder",{name, order:addOrder}).then((data)=>{
            console.log(data.data.order,"=============================");
            // let docs=data.data.order;
            setAddOrder([...addOrder,...data.data.order]);
            console.log(addOrder,"=======&&&&&&&&&&&====");
        }).catch((err)=>{
            console.log(err);
        });
    },[])
    const handleAdd = (data)=>{
       
        if( addOrder.findIndex((doc)=> data._id==doc._id)==-1){
            setAddOrder([...addOrder,data]);
        }
        console.log(addOrder,data);
    }

    const handleCancle = (data)=>{
       const docData= addOrder.filter((doc)=> data._id!=doc._id);
       console.log(docData,"=+=");
       setAddOrder([...docData]);
       axios.post("http://localhost:8000/cancleOrder",{name,order:data}).then((data)=>{
       console.log(data.data);
    }).catch((err)=>{
        console.log(err);
    });
        console.log(addOrder);
    }

  return (
    <div className="grid-container">
      {foodData.map((food, index) => (
        <div key={index} className="food-card">
          <img src={food.image} alt={food.name} className="food-image" />
          <h2 className="food-name">{food.name}</h2>
          <p className="food-description">{food.description}</p>
          <h3 className="cook-name">Cook Name: {food.cookName}  |  Time: {food.time}</h3>
          {(addOrder.findIndex((data)=>data._id==food._id)==-1)? (<Button
            variant="contained"
            color="success"
            onClick={() => handleAdd(food)}
            >Order
        </Button>):(<Button
            variant="contained"
            color="error"
            onClick={() => handleCancle(food)}
            >Cancle
        </Button>)}       
         </div>
      ))}
    </div>
  );
};

export default FoodCardGrid;

import React,{useState, useEffect} from "react";
import FoodCardGrid from "./foodCard";
import axios from 'axios';

const OrderCardGrid = () => {

    const [addOrder,setAddOrder] = useState([]);
    let name = localStorage.getItem("name");
    useEffect(()=>{
        axios.post("http://localhost:8000/getOrder",{order:addOrder}).then((data)=>{
            console.log(data.data);
        }).catch((err)=>{
            console.log(err);
        });
    },[addOrder]);

    useEffect(()=>{
        axios.post("http://localhost:8000/allOrder",{name , order:addOrder}).then((data)=>{
            // if(data){
            //     console.log(data.data);
            //     setAddOrder([...(data.data.data)]);
            // }
            console.log(data.data);
            setAddOrder([...data.data.order]);
        }).catch((err)=>{
            console.log(err);
        });
    },[])
    const handleAdd = (data)=>{
       
        if( addOrder.findIndex((doc)=> data==doc)==-1){
            setAddOrder([...addOrder,data]);
        }
        console.log(addOrder,data);
    }

    const handleCancle = (data)=>{
       const docData= addOrder.filter((doc)=> data!=doc);
       console.log(docData,"=+=");
       setAddOrder([...docData]);
       axios.post("http://localhost:8000/cancleOrder",{name,order:data}).then((data)=>{
        console.log(data.data);
    }).catch((err)=>{
        console.log(err);
    });
        console.log(addOrder);
    }

    return (
        <div>
          <h1 style={{color:"red", fontFamily:"lobster"}}>Feast Your Eyes: Spicy Dishes Await!</h1>
          <FoodCardGrid foodData={addOrder} />
        </div>
      );
};

export default OrderCardGrid;

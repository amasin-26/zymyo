import React, {useEffect, useState}  from 'react';
import FoodCardGrid from "./foodCard";
import axios from "axios";

function AvailableDishes(){

    const [AvailbleDish,setAvailableDish] =useState([]);
    const [foodData,setFoodData] = useState([]);
    const name= localStorage.getItem("name");

    useEffect(()=>{
      axios.post("http://localhost:8000/getMenu" ,{name}).then((data)=>{
        console.log(data.data,name);
        setFoodData(data.data.data);
       });
    },[]);
   
    
      return (
        <div>
          <h1 style={{color:"red", fontFamily:"lobster"}}>Feast Your Eyes: Spicy Dishes Await!</h1>
          <FoodCardGrid foodData={foodData} />
        </div>
      );
}

export default AvailableDishes;
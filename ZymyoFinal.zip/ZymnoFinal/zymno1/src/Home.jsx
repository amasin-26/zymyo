import React,{useState , useContext ,useEffect} from "react";
import "./Home.css"
import {BrowserRouter as Router, Routes, Route, Link,useLocation} from "react-router-dom";
import ChefRegister from "./LoginSignUp/ChefRegisterCard";
import ChefLogin from "./LoginSignUp/chefLogin";
import CustomerRegister from "./LoginSignUp/customerRegister";
import CustomerLogin from "./LoginSignUp/customerLogin";
import Navbar from "./Nav";
import DishManagement from "./chefProfile/dishmanage";
import DashBoardNav from "./DashBoardNav";
import { AuthContext } from "./AuthContext";
import DishManu from "./chefProfile/dishMenu";
import AvailableDishes from "./CustomerProfile/availableDishes";
import CustomerDashBoardNav from "./customerDashboard";
import OrderCardGrid from "./CustomerProfile/orderCard";
import AddDishes from "./chefProfile/addDishes";
import Logout from "./LoginSignUp/logout";

function Home(){
        
    const {isAuthenticated ,profile} = useContext(AuthContext);
    console.log(isAuthenticated ,profile)
    return (
        <div>
            <div className="background-container">
           <Router>
            {!isAuthenticated ?  <Navbar/> : profile=="customer" ?  <CustomerDashBoardNav/>:<DashBoardNav/>}
            <Routes>
                <Route path="/ChefRegister" element={<ChefRegister/>} />
                <Route path="/ChefLogin" element={<ChefLogin/>} />
                <Route path="/CustomerRegister" element={<CustomerRegister/>} />
                <Route path="/CustomerLogin" element={<CustomerLogin/>} />
            </Routes>
            {isAuthenticated?
                <Routes>
                    <Route path="/DishManagement" element={<DishManagement/>}/>
                    <Route path='/chefMenu' element={<DishManu/>}/>
                    <Route path='/orders' element={<OrderCardGrid/>}/>
                    <Route path="/Menu" element={<AvailableDishes/>}/>
                    <Route path="/AddDishes" element={<AddDishes/>}/>
                    <Route path="/Logout" element={<Logout/>}/>
                </Routes>:<></>
            }
                       {isAuthenticated? <></>:<div style={{padding:"40px" ,color:"white" , fontFamily:"pacifico"}}><h1>Craving something special? We’ve got you covered with every bite.</h1>
           <h3>From appetizers to desserts, our selection is a harmony of flavors designed to excite your taste buds. Every dish tells a story, and every bite is a part of that delicious journey.</h3></div>}

           </Router>

        </div>
        </div>
    )
}
export default Home;


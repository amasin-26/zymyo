import React,{useState , useEffect,useContext} from "react";
import "./ChefRegisterCard.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../AuthContext";
function CustomerLogin(){

    const [chefForm, setChefForm] = useState({
        email:"",
        password:"", 
    });
    const {Login, setProfile} = useContext(AuthContext);

    const navigate = useNavigate();

    const handleChange =(e)=>{
        const {name,value} = e.target;
        setChefForm({...chefForm,[name]:value});
    }

    const handleSubmit = (e)=>{
        e.preventDefault();
        console.log(chefForm);
        axios.post("http://localhost:8000/customerLogin",chefForm).then((res)=>{
            console.log("Response",res.data);
            if(res.data.msg=="verify"){
                localStorage.setItem("token",res.data.token);
                localStorage.setItem("profile", "customer");
                Login(true);
                setProfile("customer");
                navigate("/Menu");
            }
        }).catch((err)=>{
            console.log(err);
        });
    }
    return(<div className="contain-position">
            <div className="chef-container contain-positioncolumn">
                <h1>SignIn Here</h1>
                <form onSubmit={handleSubmit}>
                <table >
                    <tbody>
                    <tr>
                        <td><label>Email</label></td>
                        <td><input placeholder="Enter Your Email" name="email" onChange={handleChange} /></td>
                    </tr>
                    <tr>
                        <td><label>Password</label></td>
                        <td><input placeholder="Enter Your Password" type="password" name="password" onChange={handleChange} /></td>
                    </tr>
                    <tr>
                        <td colSpan="2" style={{textAlign:"center"}}>
                        <button type="submit">Submit</button>
                        </td>
                    </tr>
                    </tbody>
                </table>
                </form>
    </div>
    </div>)
}

export default CustomerLogin;
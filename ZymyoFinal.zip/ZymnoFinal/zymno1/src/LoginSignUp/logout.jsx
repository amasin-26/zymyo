import React from 'react';

function Logout(){

    localStorage.removeItem("token");
    localStorage.removeItem("profile");
    window.location.reload();
    return (
        <div></div>
    )
}

export default Logout;
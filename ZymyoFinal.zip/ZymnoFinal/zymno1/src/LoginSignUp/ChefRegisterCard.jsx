import React,{useState , useEffect} from "react";
import "./ChefRegisterCard.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function ChefRegister(){

    const [chefForm, setChefForm] = useState({
        name:"",
        email:"",
        password:"",
        phone:"",
        address:"",
        experience:"",
        reciepe:""
    });
    const navigate = useNavigate();

    const handleChange =(e)=>{
        const {name,value} = e.target;
        setChefForm({...chefForm,[name]:value});
    }

    const handleSubmit = (e)=>{
        e.preventDefault();
        console.log(chefForm);
        axios.post("http://localhost:8000/chefRegister",chefForm).then((res)=>{
            console.log("Response",res.data);
            if(res.data.msg=="verify"){
                navigate("/ChefLogin");
            }
        }).catch((err)=>{
            console.log(err);
        });
    }
    return(<div className="contain-position">
            <div className="chef-container contain-positioncolumn">
                <h1>Register Here, To Serve Your Specializaton</h1>
                <form onSubmit={handleSubmit}>
                <table >
                    <tbody>
                    <tr>
                        <td><label>Name</label></td>
                        <td><input placeholder="Enter Your Name" name="name" onChange={handleChange} /></td>
                    </tr>
                    <tr>
                        <td><label>Email</label></td>
                        <td><input placeholder="Enter Your Email" name="email" onChange={handleChange} /></td>
                    </tr>
                    <tr>
                        <td><label>Password</label></td>
                        <td><input placeholder="Enter Your Password" type="password" name="password" onChange={handleChange} /></td>
                    </tr>
                    <tr>
                        <td><label>Phone</label></td>
                        <td><input placeholder="Enter Your Phone" name="phone" onChange={handleChange} /></td>
                    </tr>
                    <tr>
                        <td><label>Address</label></td>
                        <td><input placeholder="Enter Your Address" name="address" onChange={handleChange} /></td>
                    </tr>
                    <tr>
                        <td><label>Experience</label></td>
                        <td><input placeholder="Enter Your Experience" name="experience" onChange={handleChange} /></td>
                    </tr>
                    <tr>
                        <td><label>Reciepies</label></td>
                        <td><input placeholder="Enter Your Reciepe" name="reciepe" onChange={handleChange} /></td>
                    </tr>
                    <tr>
                        <td colSpan="2" style={{textAlign:"center"}}>
                        <button type="submit">Submit</button>
                        </td>
                    </tr>
                    </tbody>
                </table>
                </form>
    </div>
    </div>)
}

export default ChefRegister;
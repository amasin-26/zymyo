import React from 'react';
import { BrowserRouter as Router , Route ,Routes ,Link } from 'react-router-dom';
import './Nav.css';
import DishManu from './chefProfile/dishMenu';
import AvailableDishes from './CustomerProfile/availableDishes';
import { Button } from '@mui/material';

function DashBoardNav() {
  return ( 
    <div>
    <nav className="navbar">
      <div className="logo">
        <h2 style={{fontFamily:"Georgia"}}>Foodies~Corner</h2>
      </div>
      <ul className="nav-links">
        <li>
            <Link to="/orders"><Button >Orders</Button></Link>
        </li>
         <li>
            <Link to="/chefMenu"><Button type="success">ChefMenu</Button></Link>
         </li>
         <li>
            <Link to="/Menu"><Button type="success">Menu</Button></Link>
         </li>
         <li>
            <Link to="/AddDishes"><Button type="success">AddDishes</Button></Link>
        </li>
        <li>
            <Link to="/Logout"> <Button type="error">LogOut</Button></Link>
         </li>
      </ul>
    </nav>
    </div>
  );
}

export default DashBoardNav;

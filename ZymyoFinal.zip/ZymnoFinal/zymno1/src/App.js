import logo from './logo.svg';
import './App.css';
import Home from "./Home";
import { AuthProvider } from './AuthContext';
function App() {
  document.title = "Foodiesss~Corner";
  return (
    <div className="App">
      <AuthProvider>
          <Home />
      </AuthProvider>
    </div>
  );
}

export default App;

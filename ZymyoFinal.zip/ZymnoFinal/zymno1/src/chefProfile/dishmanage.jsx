import React,{useState ,useEffect} from "react";
import DishManu from "./dishMenu";
import AvailableDishes from "../CustomerProfile/availableDishes";
import AddDishes from './addDishes';

function DishManagement(){

   return (
        <div>
            <AddDishes/>
        {/* <AvailableDishes/> */}

        </div>
    )

}

export default DishManagement;
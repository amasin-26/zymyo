import React ,{useState} from 'react';
import './addDishes.css';
import axios from "axios";

function AddDishes(){

    const cookName = localStorage.getItem("name");
    const [addDish,setAddDish]  = useState({
        image:"", name:"", description:"", cookName:"", time:"",cookName:cookName
    });

    const handleSubmit= (e)=>{
        e.preventDefault();
        console.log(addDish);
        try{
            axios.post("http://localhost:8000/addReciepe",{dish:addDish}).then((data)=>{
                console.log(data);
            }).catch((err)=>{
                console.log("error",err);
            });
        }catch(errrrr){
            console.log(errrrr);
        }
        setAddDish({ image: "", name: "", description: "", cookName: "", time: "" });
        window.location.reload(); 
    }

    const handleChange=(e)=>{
        const {name ,value} =e.target;
        setAddDish({...addDish,[name]:value});
    }
    
    return (
           <div className='dishForm'>
            <div className='demoDish'>
              <h1>Add Your New Receipe</h1>
              <form onSubmit={handleSubmit}>
                <table> 
                    <tbody>
                    <tr>
                        <td><label>Dish Name</label></td>
                    <td> 
                        <input name="name" placeholder='Enter Dish Name...' onChange={handleChange}/>
                    </td>
                </tr>
                <tr>
                    <td><label>Dish-Image URL</label></td>
                    <td><input placeholder='Upload Image URL...' name="image" onChange={handleChange}/></td>
                </tr>
                <tr>
                    <td><label>Description</label></td>
                    <td><input  placeholder='Enter Description...' name="description" onChange={handleChange}/></td>
                </tr>
                <tr>
                <td> <label>Duration</label></td>
                    <td><input  placeholder='Enter Duration...' name="time" onChange={handleChange} /></td>
                </tr>
                <tr><td colSpan="2" style={{textAlign:"center"}}><button>Submit</button></td></tr>
              </tbody>
          </table>
            </form>
           </div>
        </div>
    )

}

export default AddDishes;
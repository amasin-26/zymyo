import * as React from 'react';
import { useState, useEffect } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import "./dishTable.css";
import axios from "axios";

const paginationModel = { page: 0, pageSize: 5 };

function DishManu() {
  const name = localStorage.getItem("name");
  const [allMenu, setAllMenu] = useState([]);

  useEffect(() => {
    axios.post("http://localhost:8000/getMenu", { name }).then((data) => {
      console.log(data.data.order, "========");
      setAllMenu(data.data.data);  // Directly set data from API response
    }).catch((error) => {
      console.error("Error fetching data: ", error);
    });
  }, []);

  const handleDelete = (ID) => {
    setAllMenu(allMenu.filter((data) => data._id !== ID));
    axios.post("http://localhost:8000/deleteReciepe",{_id:ID}).then((data)=>{
      console.log(data);
    }).catch((er)=>{
      console.log(er);
    });
  };

  const columns = [
    { field: '_id', headerName: 'ID', width: 70 },
    { field: 'description', headerName: 'Description', width: 250 },
    { field: 'name', headerName: 'Name', width: 150 },
    { field: 'time', headerName: 'Cooking Duration', type: 'String', width: 150 },
    {
      field: 'action',
      headerName: 'Actions',
      width: 150,
      renderCell: (params) => (
        <Button
          variant="contained"
          color="error"
          onClick={() => handleDelete(params.row._id)}
        >
          Delete
        </Button>
      ),
    }
  ];

  return (
    <div className="table-position">
      <h1 style={{ color: "red" }}>Available Dishes in Menu! </h1>
      <Paper sx={{ height: 400, width: '70%' }}>
        <DataGrid
          rows={allMenu}
          columns={columns}
          initialState={{ pagination: { paginationModel } }}
          pageSizeOptions={[5, 10]}
          checkboxSelection
          getRowId={(row) => row._id}  // Set _id as the unique row identifier
          getRowClassName={(params) => (params.row._id % 2 !== 0 ? 'evenRow' : 'oddRow')}
          sx={{ border: 0 }}
        />
      </Paper>
    </div>
  );
}

export default DishManu;

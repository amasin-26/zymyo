import React ,{createContext ,useState,useEffect} from "react";
import axios from "axios";
export const AuthContext  = createContext();

export const AuthProvider = ({children})=>{
    const [isAuthenticated,setIsAuthenticated] = useState(false);

    const [profile,setProfile] = useState("");

    useEffect(()=>{
       let token= localStorage.getItem("token");
       let profiles= localStorage.getItem("profile");
       if(token && profiles){
        axios.post("http://localhost:8000/verifyToken",{token,profiles}).then((data)=>{
            if(data.data.data.verified){
                 setIsAuthenticated(data.data.data.authenticate);
                 setProfile(data.data.data.profile);
            }else{
                 console.log("Not Authenticated!",data);
            }
         });
       }
    },[])
    const Login = ()=>{
        setIsAuthenticated(true);
    }

    const Logout = ()=>{
        setIsAuthenticated(false);
    }

    return <AuthContext.Provider value={{isAuthenticated,profile,Login,Logout,setProfile}}>{children}</AuthContext.Provider>
}
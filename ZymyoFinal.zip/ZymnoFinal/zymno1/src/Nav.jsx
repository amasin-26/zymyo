import React from 'react';
import { Link } from 'react-router-dom';
import './Nav.css';

function Navbar() {
  return (
    <nav className="navbar">
      <div className="logo">
        <h2>Foodieesss</h2>
      </div>
      <ul className="nav-links">
        <li>
          <Link to="/ChefRegister">ChefRegister</Link>
        </li>
        <li>
          <Link to="/ChefLogin">ChefLogin</Link>
        </li>
        <li>
            <Link to="/CustomerRegister">CustomerRegister</Link>
        </li>
         <li>
            <Link to="/CustomerLogin">CustomerLogin</Link>
         </li>
      </ul>
    </nav>
  );
}

export default Navbar;

import React from 'react';
import { BrowserRouter as Router , Route ,Routes ,Link } from 'react-router-dom';
import './Nav.css';

function CustomerDashBoardNav() {
  return ( 
    <div>
    <nav className="navbar">
      <div className="logo">
        <h2 style={{fontFamily:"Georgia"}}>Foodies~Corner</h2>
      </div>
      <ul className="nav-links">
        <li>
            <Link to="/orders">Orders</Link>
        </li>
         <li>
            <Link to="/Menu">Menu</Link>
         </li>
         <li>
            <Link to="/Logout">LogOut</Link>
         </li>
      </ul>
    </nav>
    </div>
  );
}

export default CustomerDashBoardNav;
